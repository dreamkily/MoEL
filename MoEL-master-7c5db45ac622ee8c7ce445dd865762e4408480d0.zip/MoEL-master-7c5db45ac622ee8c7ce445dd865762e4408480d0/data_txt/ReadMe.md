For iNaturalist 2018, please unzip the iNaturalist_train.zip.
